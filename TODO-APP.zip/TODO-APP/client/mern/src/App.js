import { useState, useEffect } from 'react';
import './App.css';
import axios from 'axios';

function App() {
  const [itemText, setItemText] = useState('');
  const [listItems, setListItems] = useState([]);
  const [selectedItemId, setSelectedItemId] = useState(null);

  const addItem = async (e) => {
    e.preventDefault();
    try {
      if (selectedItemId) {
        // Update existing item
        await axios.put(`http://localhost:5500/api/items/${selectedItemId}`, {
          item: itemText
        });
        const updatedListItems = listItems.map(item => {
          if (item._id === selectedItemId) {
            return { ...item, item: itemText };
          }
          return item;
        });
        setListItems(updatedListItems);
        setSelectedItemId(null);
      } else {
        // Add new item
        const res = await axios.post('http://localhost:5500/api/item', { item: itemText });
        setListItems([...listItems, res.data]);
      }
      setItemText('');
    } catch (err) {
      console.log(err);
    }
  };

  useEffect(() => {
    const getListItems = async () => {
      try {
        const res = await axios.get('http://localhost:5500/api/items');
        setListItems(res.data);
      } catch (err) {
        console.log(err);
      }
    };
    getListItems();
  }, []);

  const deleteItems = async (id) => {
    try {
      await axios.delete(`http://localhost:5500/api/items/${id}`);
      const newListItems = listItems.filter(item => item._id !== id);
      setListItems(newListItems);
    } catch (err) {
      console.log(err);
    }
  };

  const updateItem = (id) => {
    const selectedItem = listItems.find(item => item._id === id);
    setItemText(selectedItem.item);
    setSelectedItemId(id);
  };

  return (
    <div className="App">
      <h1>Todo List</h1>
      <form className="form" onSubmit={e => addItem(e)}>
        <input type="text" placeholder="Add Todo list" onChange={(e) => setItemText(e.target.value)} value={itemText} />
        <button type="submit">{selectedItemId ? 'Update' : 'Add'}</button>
      </form>
      <div className="todo-items">
        {listItems.map(item => (
          <div className="todo-item" key={item._id}>
            <h2 className="item-content">{item.item}</h2>
            <button className="update-item" onClick={() => updateItem(item._id)}>Update</button>
            <button className="delete-item" onClick={() => deleteItems(item._id)}>Delete</button>
          </div>
        ))}
      </div>
    </div>
  );
}

export default App;
